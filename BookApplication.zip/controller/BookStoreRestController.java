package com.mphasis.book.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.mphasis.book.entity.Book;
import com.mphasis.book.service.BookStoreService;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookStoreRestController {

    @Autowired
    private BookStoreService bookStoreService;

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        return ResponseEntity.ok(bookStoreService.addBook(book));
    }

    @PutMapping("/{bookId}")
    public ResponseEntity<Book> updateBook(@PathVariable Long bookId, @RequestBody Book bookDetails) {
        return ResponseEntity.ok(bookStoreService.updateBook(bookId, bookDetails));
    }

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookStoreService.findAllBooks());
    }

    @GetMapping("/{bookId}")
    public ResponseEntity<Book> getBookById(@PathVariable Long bookId) {
        return ResponseEntity.ok(bookStoreService.findBookById(bookId));
    }

    @DeleteMapping("/{bookId}")
    public ResponseEntity<Void> deleteBookById(@PathVariable Long bookId) {
        bookStoreService.deleteBookById(bookId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/title/{title}") // Adjusted for camelCase
    public ResponseEntity<List<Book>> getBooksByTitle(@PathVariable String title) {
        return ResponseEntity.ok(bookStoreService.findBooksByTitle(title));
    }

    @GetMapping("/publisher/{publisher}") // Adjusted for camelCase
    public ResponseEntity<List<Book>> getBooksByPublisher(@PathVariable String publisher) {
        return ResponseEntity.ok(bookStoreService.findBooksByPublisher(publisher));
    }

    @GetMapping("/year")
    public ResponseEntity<List<Book>> getBooksByYear(@RequestParam int publishYear) {
        return ResponseEntity.ok(bookStoreService.findBooksByYear(publishYear)); // Changed from year to publishYear
    }

}
