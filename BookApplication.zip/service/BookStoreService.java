package com.mphasis.book.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.book.entity.Book;
import com.mphasis.book.repo.BookStoreRepository;

import java.util.List;

@Service
public class BookStoreService {

    @Autowired
    private BookStoreRepository bookStoreRepository;

    public Book addBook(Book book) {
        return bookStoreRepository.save(book);
    }

    public Book updateBook(Long id, Book bookDetails) {
        Book book = bookStoreRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found"));
    
        book.setTitle(bookDetails.getTitle());
        book.setPublisher(bookDetails.getPublisher());
        book.setPublishYear(bookDetails.getPublishYear());
        book.setNumberOfPages(bookDetails.getNumberOfPages());
        book.setIsbn(bookDetails.getIsbn());
        return bookStoreRepository.save(book);
    }

    public List<Book> findAllBooks() {
        return bookStoreRepository.findAll();
    }

    public Book findBookById(Long id) {
        return bookStoreRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found"));
    }

    public void deleteBookById(Long id) {
        bookStoreRepository.deleteById(id);
    }

    public List<Book> findBooksByTitle(String title) {
        return bookStoreRepository.findByTitle(title);
    }

    public List<Book> findBooksByPublisher(String publisher) {
        return bookStoreRepository.findByPublisherLike(publisher);
    }
    public List<Book> findBooksByYear(int publishYear) {
        return bookStoreRepository.findByPublishYear(publishYear); // Changed from findByYear
    }

}
