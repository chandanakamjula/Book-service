package com.mphasis.book.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.mphasis.book.entity.Book;

import java.util.List;

public interface BookStoreRepository extends JpaRepository<Book, Long> {
    List<Book> findByTitle(String title);
    List<Book> findByPublisherLike(String publisher);
    List<Book> findByPublishYear(int publishYear); // Changed from findByYear
}
