package com.mphasis.eBookStore_Consumer_Hystrix.Service;

import java.awt.print.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.ribbon.proxy.annotation.Hystrix;

@Service
public class BookService {
	  private final RestTemplate restTemplate;

	    public BookService(RestTemplate restTemplate) {
	        this.restTemplate = restTemplate;
	    }

	    @Hystrix(fallbackMethod = "fallbackForGetBookById")
	    public Book getBookById(int id) {
	        return restTemplate.getForObject("http://ebook-service/books/" + id, Book.class);
	    }

	    // Fallback method
	    public Book fallbackForGetBookById(int id) {
	        // Return a default Book or null
	        return new Book(id, "Default Book Title", "Fallback Author");
	    }
}
