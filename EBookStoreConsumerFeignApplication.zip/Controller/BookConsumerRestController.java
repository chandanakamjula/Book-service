package com.mphasis.eBookStore_Consumer_Feign.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.eBookStore_Consumer_Feign.repo.BookServiceProxy;

import java.awt.print.Book;
import java.util.List;

@RestController
public class BookConsumerRestController {

    @Autowired
    private BookServiceProxy bookServiceProxy;

    @GetMapping("/get-books")
    public List<Object> getBooks() {
        return bookServiceProxy.getAllBooks();
    }

    @GetMapping("/get-books/{id}")
    public Object getBook(@PathVariable Long id) {
        return bookServiceProxy.getBookById(id);
    }
}

