package com.mphasis.eBookStore_Consumer_Feign.repo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.MediaType;


import java.util.List;

@FeignClient(name = "book-service", url = "http://localhost:9090")
public interface BookServiceProxy {

    @GetMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE})
    List<Object> getAllBooks();

    @GetMapping(value = "/books/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
    Object getBookById(@PathVariable("id") Long id);
}
