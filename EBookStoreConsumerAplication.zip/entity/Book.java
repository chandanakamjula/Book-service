package com.mphasis.eBookStore_Consumer.entity;

public class Book {
	private int id;
	private String bookTitle;
	private String bookAuthor;
	private String bookPublisher;
	private String BookIsbn;
	private Integer noOfPages;
	private Integer bookYear;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return bookTitle;
	}
	public void setTitle(String title) {
		this.bookTitle = title;
	}
	public String getAuthor() {
		return bookAuthor;
	}
	public void setAuthor(String author) {
		this.bookAuthor = author;
	}
	public String getPublisher() {
		return bookPublisher;
	}
	public void setPublisher(String publisher) {
		this.bookPublisher = publisher;
	}
	public String getIsbn() {
		return BookIsbn;
	}
	public void setIsbn(String isbn) {
		this.BookIsbn = isbn;
	}
	public Integer getNoOfPages() {
		return noOfPages;
	}
	public void setNoOfPages(Integer noOfPages) {
		this.noOfPages = noOfPages;
	}
	public Integer getYear() {
		return bookYear;
	}
	public void setYear(Integer year) {
		this.bookYear = year;
	}
 
 
}