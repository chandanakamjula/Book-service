package com.mphasis.eBookStore_Consumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.mphasis.eBookStore_Consumer.entity.Book;

@RestController
//@RequestMapping("/books")  // Optional: Base path for all book-related endpoints
public class BookConsumerRestController {
	
    private final RestTemplate restTemplate;

    // Constructor Injection
    @Autowired
    public BookConsumerRestController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/get-books/{id}")
    public ResponseEntity<?> getBook(@PathVariable("id") int id) {
        String url = "http://book-service/books/" + id;
        try {
            Book book = restTemplate.getForObject(url, Book.class);
            return ResponseEntity.ok(book);
        } catch (HttpServerErrorException e) {
            // Log the error and return a meaningful message
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving book: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unexpected error: " + e.getMessage());
        }
    }

}
